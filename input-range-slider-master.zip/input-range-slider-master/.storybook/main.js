module.exports = {
  stories: ['../dist/stories/**/*.stories.{js,md,mdx}'],
};
