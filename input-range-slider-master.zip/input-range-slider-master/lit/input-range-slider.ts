import { InputRangeSlider } from '../src/lit/InputRangeSlider.js';

window.customElements.define('input-range-slider', InputRangeSlider);
