export { InputRangeSlider } from '../src/lit/InputRangeSlider.js';
