import { InputRangeSlider } from './src/InputRangeSlider.js';

window.customElements.define('input-range-slider', InputRangeSlider);
