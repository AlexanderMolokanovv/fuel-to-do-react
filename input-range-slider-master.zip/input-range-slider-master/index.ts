export { InputRangeSlider } from './src/InputRangeSlider.js';
